contacts = []

def read_contacts(massive)
	cntbase = File.open("contacts.txt")
	cntbase.each_line do |line|
		name1, phone1 = line.split(": ")
		cntrd = {
		name: name1,phone: phone1}
		massive.push cntrd
	end
end

def write_contacts(massive)
	cntbase = File.new("contacts.txt", "w")
	massive.each do |hash|
		string = "#{hash[:name]}: #{hash[:phone]} "
		cntbase.write string + "\n"
	end
end

def find_by_name(contacts, search_name)
	contacts.each do |contact|
		if contact[:name] == search_name
		 return contact
		end
	end
	return nil
end

def input()
	print ">"
	string=gets.chomp
	return string
end

puts "\nPhone Book by fedyay v1.1"
puts "!!!Type help to get all commands list!!!"

read_contacts(contacts)

loop do
	puts "\nEnter command:"
	command = input()
	
	case command
	when "list"
		puts "\n"
		puts "============================"
		contacts.each do |contact|
			puts "Name:  #{contact[:name]}"
			puts "Phone: #{contact[:phone]}"
			puts "============================"
		end
		
	when "find"
		puts "\nSearch for:"
		search_name = input()
		puts "\n"
		contact = find_by_name(contacts, search_name)
		if contact.nil?
			puts "Contact not found :("
		else
			puts "============================"
			puts "Name:  #{contact[:name]}"
			puts "Phone: #{contact[:phone]}"
			puts "============================"
		end
		
	when "add"
		puts "\nEnter new contact name:"
		new_name = input()
		contact = find_by_name(contacts, new_name)
		if contact.nil?
			puts "\nEnter new phone number:"
			new_phone = input()
			new_contact={name: new_name, phone: new_phone}
			contacts.push new_contact
			puts "\nContact created."
			write_contacts(contacts)
		else
			puts "\nThis contact already exists."
		end
		
	when "edit"
		puts "\nWhich contact do you want to edit?"
		edit_name = input()
		contact = find_by_name(contacts, edit_name)
		if contact.nil?
			puts "\nThis contact doesn't exists."
		else
			puts "\nEnter new phone number:"
			contact[:phone] = input()
			puts "\nContact modified."
			write_contacts(contacts)
		end
			
	when "delete"
		puts "\nWhich contact do you want to delete?"
		delete_name = input()
		contact = find_by_name(contacts, delete_name)
		if contact.nil?
			puts "\nThis contact doesn't exists."
		else
			contacts.delete_if { |h| h[:name] == delete_name }
			puts "\nDeleted."
			write_contacts(contacts)
		end
		
	when "help"
		puts "\nlist"
		puts "find"
		puts "add"
		puts "edit"
		puts "delete"
		puts "exit"
		
	when "exit"
		puts "\nBye..."
		break
		
	else
	 puts "\nCommand not found"
	end
	
end
























